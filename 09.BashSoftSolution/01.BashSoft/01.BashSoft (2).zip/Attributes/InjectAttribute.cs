﻿using System;
using System.Collections.Generic;
using System.Text;
[AttributeUsage(AttributeTargets.Field)]
public class InjectAttribute:Attribute
{

}
