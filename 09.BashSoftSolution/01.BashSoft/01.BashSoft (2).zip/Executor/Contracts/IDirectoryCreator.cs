﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IDirectoryCreator
{
    void CreateDirectoryInCurrentFolder(string name);
}