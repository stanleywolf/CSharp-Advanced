﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IDirectoryTraverser
{
    void TraverseDirectory(int depth);
}