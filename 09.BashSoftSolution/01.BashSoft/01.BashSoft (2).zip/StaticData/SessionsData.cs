﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

public static class SessionsData
{
    public static string currentPath = Directory.GetCurrentDirectory();
}

